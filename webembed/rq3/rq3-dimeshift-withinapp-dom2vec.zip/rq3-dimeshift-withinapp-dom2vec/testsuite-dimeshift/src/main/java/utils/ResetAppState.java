package utils;

import java.util.Arrays;
import java.util.List;

public class ResetAppState {

    public static void reset(){
        // TODO
    }
}
