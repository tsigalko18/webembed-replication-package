// setup.js
$(function() {

	App.init();

});